import unittest

class Anagrams:

    def __init__(self, wordsfile):
        self.words = open(wordsfile).readlines()
        #self.words = open('words.txt').readlines()

    def get_anagrams(self, word):
        word_key = sorted(word.lower())
        matches = [word for word in words if sorted(word.lower()) == word_key]
        return matches
        
        #pass